﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Studenti.AvaloniaClient.ViewModels;

public class ViewModelBase : ObservableObject
{
}
