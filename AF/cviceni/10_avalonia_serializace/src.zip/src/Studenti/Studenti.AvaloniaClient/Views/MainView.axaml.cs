﻿using Avalonia.Controls;

namespace Studenti.AvaloniaClient.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}
