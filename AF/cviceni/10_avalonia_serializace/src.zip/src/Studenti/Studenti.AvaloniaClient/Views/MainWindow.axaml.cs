﻿using Avalonia.Controls;

namespace Studenti.AvaloniaClient.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
